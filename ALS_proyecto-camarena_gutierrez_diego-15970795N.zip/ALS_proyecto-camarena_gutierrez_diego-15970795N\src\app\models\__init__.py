"""
Modelos de datos de la aplicación.
"""
