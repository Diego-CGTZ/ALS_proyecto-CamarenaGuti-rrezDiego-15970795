"""
Formularios de la aplicación usando Flask-WTF.
"""
